### horchunk

This package contains novel methods for semantic chunking in RAG applications.
